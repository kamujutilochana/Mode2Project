package com.pack.IrctcUser.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.IrctcUser.Dao.UserDao;
import com.pack.IrctcUser.Dto.LoginDto;
import com.pack.IrctcUser.exception.UserNotFoundException;
import com.pack.IrctcUser.model.User;

@Service
public class UserService {

	@Autowired
	UserDao userDao;

	public String userLogin(LoginDto loginDto, String userId) {
		Optional<User> user = userDao.findById(userId);

		if (user.get().getUserName().equals(loginDto.getUserName()) && user.get().getPassword().equals(loginDto.getPassword())
				&& user.get().getUserId().equals(userId)) {
			return "user logined successfully";
		} else
			throw new UserNotFoundException("User not registered,please register");

	}

	public String addUser(User user) {
		int random = (int) (Math.random() * 50 + 1);
		String userid = user.getUserName() + random;
		user.setUserId(userid);
		userDao.save(user);
		return "Succesfully registered!! " + "This is your userID :" + user.getUserId();
	}

}
